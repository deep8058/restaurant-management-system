package com.deep.restaurant;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MenuItemDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/RestaurantDB";
    private static final String USER = "root";
    private static final String PASSWORD = "#Deepanshu@123";

    public void addMenuItem(MenuItem item) {
        String query = "INSERT INTO MenuItem (itemName, itemPrice) VALUES (?, ?)";
        try (Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/RestaurantDB", "root", "#Deepanshu@123");
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, item.getItemName());
            ps.setBigDecimal(2, item.getItemPrice());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<MenuItem> getAllMenuItems() {
        List<MenuItem> items = new ArrayList<>();
        String query = "SELECT * FROM MenuItem";
        try (Connection con = DriverManager.getConnection( "jdbc:mysql://localhost:3306/RestaurantDB", "root",  "#Deepanshu@123");
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                MenuItem item = new MenuItem();
                item.setItemId(rs.getInt("itemId"));
                item.setItemName(rs.getString("itemName"));
                item.setItemPrice(rs.getBigDecimal("itemPrice"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
}
