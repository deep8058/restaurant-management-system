package com.deep.restaurant;
 
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/MenuItemServlet")
public class MenuItemServlet extends HttpServlet {
    private MenuItemDAO menuItemDAO = new MenuItemDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            StringBuilder sb = new StringBuilder();
            String s;
            while ((s = request.getReader().readLine()) != null) {
                sb.append(s);
            }  

            Gson gson = new Gson();
            MenuItem item = gson.fromJson(sb.toString(), MenuItem.class);
            menuItemDAO.addMenuItem(item);
            out.print("{\"success\":true}");
        } catch (Exception e)
        {
            out.print("{\"success\":false}");
            e.printStackTrace();
        }
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            List<MenuItem> items = menuItemDAO.getAllMenuItems();
            Gson gson = new Gson();
            out.print(gson.toJson(items));
        } catch (Exception e) {
            e.printStackTrace();
        }
        out.flush();
    }
}
