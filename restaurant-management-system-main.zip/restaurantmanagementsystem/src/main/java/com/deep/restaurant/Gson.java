package com.deep.restaurant;

import java.util.List;

public class Gson {

	public MenuItem fromJson(String string, Class<MenuItem> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	public char[] toJson(List<MenuItem> items) {
		// TODO Auto-generated method stub
		return null;
	}

}
